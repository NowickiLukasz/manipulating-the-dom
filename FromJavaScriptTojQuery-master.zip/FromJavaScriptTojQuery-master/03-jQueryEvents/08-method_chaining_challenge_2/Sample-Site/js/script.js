$(document).ready(function() {
 //
 // add your jQuery code here
 $("button").click(function() {
    $("p").slideToggle(2000);
});

}); 
