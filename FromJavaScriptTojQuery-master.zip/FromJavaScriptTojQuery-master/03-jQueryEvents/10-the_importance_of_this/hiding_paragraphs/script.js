$('p').click(function() {
	$(this).slideToggle('slow');
});