$(document).ready(function() {
    $("tr:odd").addClass("odd");
    $("tr:even").addClass("even");
});